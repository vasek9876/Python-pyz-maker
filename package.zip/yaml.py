print("ahoj") ##
