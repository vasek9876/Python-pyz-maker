print("nic")
