print("ahoj jak se mas")
